import axios from 'axios';

const MY_SERVER = 'http://127.0.0.1:5000' 

export const fetchStockData = async (tickerSymbol) => {
  try {
    const response = await axios.post(`${MY_SERVER}/get_stock`, {ticker:tickerSymbol});
    return response.data;
  } catch (error) {
    console.error('Error fetching stock data:', error);
  }
};
