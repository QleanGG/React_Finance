import React, { useState, useEffect } from 'react';
import { fetchStockData } from '../services/stockService';
import stockList from '../json/nasdaq_listed.json';
import './StockSearch.css';
// import StockChart from './StockChart';


function StockSearch() {
  const [inputValue, setInputValue] = useState(''); // For the input display
  const [tickerSymbol, setTickerSymbol] = useState(''); // For the actual ticker symbol
  const [stockData, setStockData] = useState(null);
  const [error, setError] = useState('');
  const [filteredOptions, setFilteredOptions] = useState([]); // For filtered options

  useEffect(() => {
    // Filter the stock list based on the input value
    const filtered = stockList.filter(item => 
      item["Company Name"].toLowerCase().includes(inputValue.toLowerCase())
    ).slice(0, 50); // Limit the number of options displayed

    setFilteredOptions(filtered);
  }, [inputValue]); // Update the filtered options whenever the input value changes

  const handleInputChange = (e) => {
    setInputValue(e.target.value);
    const stock = stockList.find(item => item["Company Name"] === e.target.value);
    if (stock) {
      setTickerSymbol(stock.Symbol);
    }
  };

  const handleSearch = async () => {
    if (!tickerSymbol) {
      setError('Please select a valid company from the list');
      return;
    }

    try {
      const data = await fetchStockData(tickerSymbol);
      setStockData(data);
      setError('');
    } catch (err) {
      setError('Failed to fetch stock data');
      setStockData(null);
    }
  };

  return (
    <div className='stock-search-container'>
      <input
        type="text"
        value={inputValue}
        onChange={handleInputChange}
        placeholder="Enter Company Name"
        list="stock-datalist"
      />
      <datalist
        id="stock-datalist"
        style={{
          position: 'absolute',
          top: '100%',
          left: '0', // Ensure it's aligned with the input
        }}
      >
        {filteredOptions.map((item, index) => (
          <option key={index} value={item["Company Name"]} />
        ))}
      </datalist>

      <button className='search-btn' onClick={handleSearch}>Search</button>

      {error && <p>{error}</p>}

      {stockData && (
        <div>
          <h3>Stock Information for: {stockData.companyName}</h3>
          <h3>Ticker {stockData.ticker}</h3>
          <h4>Current Price: {stockData.currentPrice}</h4>
          {/* <StockChart data={stockData} /> */}
        </div>
      )}
    </div>
  );
}

export default StockSearch;
