import React from 'react';
import StockChart from './StockChart';

const StockPage = () => {
  const chartData = {
    
  };

  return (
    <div>
      <h1>Stock Chart</h1>
      <StockChart data={chartData} />
    </div>
  );
};

export default StockPage;
