import React from 'react';
// import { Line } from 'react-chartjs-2';

// const StockChart = ({ data }) => {
//   // Prepare the chart data
//   const chartData = {
//     labels: data.historicalData.map((entry) => entry.date),
//     datasets: [
//       {
//         label: 'Stock Price',
//         data: data.historicalData.map((entry) => entry.close),
//         borderColor: 'rgba(75, 192, 192, 1)',
//         borderWidth: 2,
//       },
//     ],
//   };

//   return (
//     <div>
//       <Line data={chartData} options={{ responsive: true }} />
//     </div>
//   );
// };

// export default StockChart;
