import React, { useState, useEffect } from 'react';
import { fetchStockData } from '../services/stockService';

function StockData() {
  const [data, setData] = useState(null);

  useEffect(() => {
    const fetchData = async () => {
      const result = await fetchStockData();
      setData(result);
    };

    fetchData();
  }, []);

  return (
    <div>
      {data && <div>Current price of ${data.ticker}: {data.currentPrice}</div>}
    </div>
  );
}

export default StockData;
